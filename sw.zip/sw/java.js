// Import necessary modules
const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');
require('dotenv').config(); // Load environment variables from .env file

const app = express();
const PORT = process.env.PORT || 3000; // Server will run on port 3000

// Middleware Setup
// 1. CORS: Allows your frontend (running on a different port/address) to communicate with this server.
//    (In a production environment, you should limit this to your website's domain only.)
app.use(cors());

// 2. Express JSON parser: Allows the server to read the JSON data sent from the frontend.
app.use(express.json());


// --- Nodemailer Transporter Setup ---
// This is the object that knows how to send the email (using SMTP settings).
const transporter = nodemailer.createTransport({
    service: 'gmail', // Use 'gmail', 'Outlook', or specify host/port for others
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
    }
});


// --- Booking API Endpoint ---
app.post('/api/book', async (req, res) => {
    const { customerName, customerPhone, vehicle, vehiclePrice, vehicleId } = req.body;

    if (!customerName || !customerPhone || !vehicle) {
        return res.status(400).json({ message: 'Missing required booking details.' });
    }

    // Email Content
    const mailOptions = {
        from: process.env.EMAIL_USER,
        to: process.env.RECIPIENT_EMAIL, // The email address of the seller/company
        subject: `NEW BOOKING REQUEST - Vehicle ID: ${vehicleId} (${vehicle})`,
        html: `
            <div style="font-family: Arial, sans-serif; padding: 20px; border: 1px solid #ccc; border-radius: 8px;">
                <h2 style="color: #08d3ff;">ALPHA 360 - New Booking Request</h2>
                <p>A customer has shown interest in one of your listings and is requesting contact.</p>
                <hr style="border-top: 1px solid #eee;">
                
                <h3 style="color: #333;">Vehicle Details:</h3>
                <ul>
                    <li><strong>Vehicle:</strong> ${vehicle}</li>
                    <li><strong>Expected Price:</strong> ${vehiclePrice}</li>
                    <li><strong>Listing ID:</strong> ${vehicleId}</li>
                </ul>
                
                <h3 style="color: #333;">Customer Contact Details:</h3>
                <ul>
                    <li><strong>Name:</strong> ${customerName}</li>
                    <li><strong>Phone:</strong> +91 ${customerPhone}</li>
                </ul>
                
                <p style="margin-top: 20px; color: #555;">Please contact the customer as soon as possible to finalize the booking.</p>
            </div>
        `
    };

    try {
        await transporter.sendMail(mailOptions);
        console.log(`Booking request for ${vehicle} sent successfully.`);
        res.status(200).json({ message: 'Booking request sent successfully.' });
    } catch (error) {
        console.error('Error sending email:', error);
        res.status(500).json({ message: 'Failed to send booking email.', error: error.message });
    }
});


// Start the server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`Email User: ${process.env.EMAIL_USER}`);
});